/**
 * Generic site JavaScript.
 */
