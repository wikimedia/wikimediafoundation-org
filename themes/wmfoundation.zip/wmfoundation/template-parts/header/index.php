<?php
/**
 * The header main index.
 *
 * This closes out the parent header component for baseline templates
 *
 * @package wmfoundation
 */

?>

</div>
</header>

<main id="content" role="main">
